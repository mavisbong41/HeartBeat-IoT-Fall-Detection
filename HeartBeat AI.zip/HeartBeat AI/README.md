
  # HeartBeat AI

  This is a code bundle for HeartBeat AI. The original project is available at https://www.figma.com/design/PWIYJwOKh6T63kUkF0Y0eZ/HeartBeat-AI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  