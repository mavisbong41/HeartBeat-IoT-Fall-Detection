import { BrowserRouter, Routes, Route } from "react-router";
import Dashboard from "./screens/Dashboard";
import EmergencyAlert from "./screens/EmergencyAlert";
import CaregiverTracking from "./screens/CaregiverTracking";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/emergency" element={<EmergencyAlert />} />
        <Route path="/caregiver-tracking" element={<CaregiverTracking />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
