import { motion } from "motion/react";

export function PulseWaveIcon() {
  const bars = Array.from({ length: 30 }, (_, i) => i);

  return (
    <div className="flex items-center justify-center gap-1.5 h-32">
      {bars.map((i) => (
        <motion.div
          key={i}
          className="w-2 bg-white rounded-full shadow-lg"
          animate={{
            height: [30, 80, 30],
          }}
          transition={{
            duration: 0.8,
            repeat: Infinity,
            delay: i * 0.03,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}
