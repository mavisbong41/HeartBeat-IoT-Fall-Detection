import { useEffect, useRef } from "react";

interface SkeletonOverlayProps {
  width: number;
  height: number;
  isFallen?: boolean;
}

export function SkeletonOverlay({ width, height, isFallen = false }: SkeletonOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Mock skeletal tracking points - FALLEN POSE (person lying horizontally on the ground)
    const skeletonPoints = isFallen ? [
      // Head (on the left when lying down)
      { x: width * 0.25, y: height * 0.5 },
      // Shoulders (horizontal)
      { x: width * 0.35, y: height * 0.45 },
      { x: width * 0.35, y: height * 0.55 },
      // Elbows
      { x: width * 0.45, y: height * 0.42 },
      { x: width * 0.45, y: height * 0.58 },
      // Hands
      { x: width * 0.52, y: height * 0.4 },
      { x: width * 0.52, y: height * 0.6 },
      // Hips (horizontal)
      { x: width * 0.6, y: height * 0.47 },
      { x: width * 0.6, y: height * 0.53 },
      // Knees
      { x: width * 0.72, y: height * 0.46 },
      { x: width * 0.72, y: height * 0.54 },
      // Feet
      { x: width * 0.82, y: height * 0.45 },
      { x: width * 0.82, y: height * 0.55 },
    ] : [
      // Standing pose (original)
      { x: width * 0.5, y: height * 0.15 },
      { x: width * 0.4, y: height * 0.25 },
      { x: width * 0.6, y: height * 0.25 },
      { x: width * 0.35, y: height * 0.4 },
      { x: width * 0.65, y: height * 0.4 },
      { x: width * 0.32, y: height * 0.55 },
      { x: width * 0.68, y: height * 0.55 },
      { x: width * 0.45, y: height * 0.55 },
      { x: width * 0.55, y: height * 0.55 },
      { x: width * 0.44, y: height * 0.75 },
      { x: width * 0.56, y: height * 0.75 },
      { x: width * 0.43, y: height * 0.92 },
      { x: width * 0.57, y: height * 0.92 },
    ];

    const connections = [
      [0, 1], [0, 2], // Head to shoulders
      [1, 2], // Shoulders
      [1, 3], [2, 4], // Shoulders to elbows
      [3, 5], [4, 6], // Elbows to hands
      [1, 7], [2, 8], // Shoulders to hips
      [7, 8], // Hips
      [7, 9], [8, 10], // Hips to knees
      [9, 11], [10, 12], // Knees to feet
    ];

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw connections with glow effect for fallen state
    if (isFallen) {
      ctx.shadowColor = "#2196F3";
      ctx.shadowBlur = 10;
    }
    ctx.strokeStyle = isFallen ? "#2196F3" : "#2196F3";
    ctx.lineWidth = 3;
    connections.forEach(([start, end]) => {
      ctx.beginPath();
      ctx.moveTo(skeletonPoints[start].x, skeletonPoints[start].y);
      ctx.lineTo(skeletonPoints[end].x, skeletonPoints[end].y);
      ctx.stroke();
    });

    // Draw points with glow
    ctx.fillStyle = isFallen ? "#FF4B4B" : "#2196F3";
    if (isFallen) {
      ctx.shadowColor = "#FF4B4B";
      ctx.shadowBlur = 15;
    }
    skeletonPoints.forEach((point) => {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw bounding box
    ctx.shadowBlur = 0;
    ctx.strokeStyle = isFallen ? "#FF4B4B" : "#2196F3";
    ctx.lineWidth = 3;
    ctx.setLineDash([8, 5]);
    
    if (isFallen) {
      // Horizontal bounding box for fallen person
      const padding = 25;
      ctx.strokeRect(
        width * 0.22 - padding,
        height * 0.38 - padding,
        width * 0.63 + padding * 2,
        height * 0.24 + padding * 2
      );
    } else {
      // Vertical bounding box for standing person
      const padding = 20;
      ctx.strokeRect(
        width * 0.3 - padding,
        height * 0.12 - padding,
        width * 0.4 + padding * 2,
        height * 0.82 + padding * 2
      );
    }
  }, [width, height, isFallen]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="absolute inset-0 pointer-events-none"
    />
  );
}