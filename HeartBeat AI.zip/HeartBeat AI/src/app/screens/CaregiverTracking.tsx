import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import { MapPin, Phone, Share2, User, Clock, Hospital, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router";

export default function CaregiverTracking() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const navigate = useNavigate();
  const [eta, setEta] = useState(360); // ETA in seconds

  useEffect(() => {
    const timer = setInterval(() => {
      setEta((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas with light background
    ctx.fillStyle = "#E8F5E9";
    ctx.fillRect(0, 0, width, height);

    // Draw mock streets (more detailed)
    ctx.strokeStyle = "#CFD8DC";
    ctx.lineWidth = 8;
    
    // Main roads
    [100, 200, 300].forEach((y) => {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    });

    [120, 280, 440].forEach((x) => {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    });

    // Draw route line (from ambulance to senior)
    ctx.strokeStyle = "#2196F3";
    ctx.lineWidth = 4;
    ctx.setLineDash([10, 5]);
    ctx.beginPath();
    ctx.moveTo(150, 120);
    ctx.lineTo(220, 180);
    ctx.lineTo(320, 240);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw senior's location marker (red pin)
    const seniorX = 320;
    const seniorY = 240;
    
    // Pin shadow
    ctx.fillStyle = "rgba(0, 0, 0, 0.2)";
    ctx.beginPath();
    ctx.ellipse(seniorX, seniorY + 35, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Pin body
    ctx.fillStyle = "#FF4B4B";
    ctx.beginPath();
    ctx.arc(seniorX, seniorY, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(seniorX, seniorY);
    ctx.lineTo(seniorX - 8, seniorY + 24);
    ctx.lineTo(seniorX, seniorY + 32);
    ctx.lineTo(seniorX + 8, seniorY + 24);
    ctx.closePath();
    ctx.fill();

    // Pin inner circle
    ctx.fillStyle = "white";
    ctx.beginPath();
    ctx.arc(seniorX, seniorY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Draw ambulance location (blue circle)
    const ambX = 150;
    const ambY = 120;
    ctx.fillStyle = "#2196F3";
    ctx.beginPath();
    ctx.arc(ambX, ambY, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "white";
    ctx.font = "bold 20px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("🚑", ambX, ambY);

    // Add street labels
    ctx.fillStyle = "#666";
    ctx.font = "14px sans-serif";
    ctx.fillText("Main Street", 240, 190);
    ctx.fillText("Oak Avenue", 290, 80);

    // Add distance marker
    ctx.fillStyle = "#2196F3";
    ctx.fillRect(210, 140, 80, 36);
    ctx.fillStyle = "white";
    ctx.font = "bold 14px sans-serif";
    ctx.fillText("2.4 mi", 250, 158);
  }, []);

  const timeline = [
    { 
      event: "Fall Detected by AI", 
      time: "10:30 AM", 
      status: "completed",
      icon: AlertCircle,
      color: "#F39C12"
    },
    { 
      event: "Voice Verification No Response", 
      time: "10:31 AM", 
      status: "completed",
      icon: XCircle,
      color: "#FF4B4B"
    },
    { 
      event: "Caregiver Notified", 
      time: "10:31 AM", 
      status: "completed",
      icon: CheckCircle2,
      color: "#2ECC71"
    },
    { 
      event: "Ambulance Auto-Dispatched", 
      time: "10:32 AM", 
      status: "active",
      icon: CheckCircle2,
      color: "#2196F3"
    },
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      {/* Emergency Header */}
      <motion.header
        className="bg-gradient-to-r from-[#FF4B4B] to-[#FF6B6B] px-4 py-6 shadow-xl"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", damping: 20 }}
      >
        <div className="max-w-md mx-auto">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold text-white">EMERGENCY DISPATCHED</h1>
            <p className="text-white text-lg font-semibold">Estimated Time of Arrival: {Math.ceil(eta / 60)} MIN</p>
          </div>
        </div>
      </motion.header>

      <div className="max-w-md mx-auto px-4 py-6 space-y-4">
        {/* Map Widget */}
        <motion.section
          className="bg-white rounded-[24px] overflow-hidden shadow-xl"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <div className="p-4 pb-3 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#FF4B4B]" />
                <h2 className="font-bold text-[#1A1A1A]">Live GPS Location</h2>
              </div>
              <motion.div
                className="w-2 h-2 bg-[#FF4B4B] rounded-full"
                animate={{ opacity: [1, 0.3, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </div>
          </div>
          
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={560}
              height={400}
              className="w-full"
            />
          </div>

          <div className="p-4 bg-gray-50">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-[#FF4B4B]/10 rounded-[12px] flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-[#FF4B4B]" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-[#1A1A1A]">123 Maple Street</p>
                <p className="text-sm text-gray-600">Springfield, CA 94102</p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Quick Dial Contacts */}
        <div className="grid grid-cols-2 gap-3">
          {/* Main Caregiver Card */}
          <motion.section
            className="bg-white rounded-[24px] p-4 shadow-lg"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex flex-col items-center text-center mb-3">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-purple-600 rounded-[14px] flex items-center justify-center shadow-lg mb-2">
                <User className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
              <h3 className="font-bold text-[#1A1A1A] text-sm">Jane Chen</h3>
              <p className="text-xs text-gray-600 font-semibold">Main Caregiver</p>
            </div>

            <button
              className="w-full bg-gradient-to-r from-[#2ECC71] to-[#27AE60] text-white rounded-[16px] py-3 px-4 shadow-lg hover:shadow-xl active:scale-98 transition-all"
              onClick={() => {}}
            >
              <div className="flex items-center justify-center gap-2">
                <Phone className="w-4 h-4" />
                <span className="text-sm font-bold">Call Now</span>
              </div>
            </button>
          </motion.section>

          {/* Nearest Hospital Card */}
          <motion.section
            className="bg-white rounded-[24px] p-4 shadow-lg"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.25 }}
          >
            <div className="flex flex-col items-center text-center mb-3">
              <div className="w-14 h-14 bg-gradient-to-br from-red-400 to-red-600 rounded-[14px] flex items-center justify-center shadow-lg mb-2">
                <Hospital className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
              <h3 className="font-bold text-[#1A1A1A] text-sm">Central Hospital</h3>
              <p className="text-xs text-gray-600 font-semibold">1.2 mi away</p>
            </div>

            <button
              className="w-full bg-gradient-to-r from-[#FF4B4B] to-[#FF6B6B] text-white rounded-[16px] py-3 px-4 shadow-lg hover:shadow-xl active:scale-98 transition-all"
              onClick={() => {}}
            >
              <div className="flex items-center justify-center gap-2">
                <Phone className="w-4 h-4" />
                <span className="text-sm font-bold">Call ER</span>
              </div>
            </button>
          </motion.section>
        </div>

        {/* Event Timeline */}
        <motion.section
          className="bg-white rounded-[24px] p-5 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-[#1A1A1A]" />
            <h3 className="font-bold text-[#1A1A1A]">Emergency Timeline</h3>
          </div>
          
          <div className="space-y-4">
            {timeline.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={i}
                  className="flex items-start gap-3 relative"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + i * 0.1 }}
                >
                  {/* Timeline line */}
                  {i < timeline.length - 1 && (
                    <div 
                      className="absolute left-[15px] top-[32px] w-0.5 h-[calc(100%+8px)] bg-gray-200"
                    />
                  )}
                  
                  {/* Icon */}
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 z-10 ${
                      item.status === 'active' ? 'ring-4 ring-blue-100' : ''
                    }`}
                    style={{ backgroundColor: item.color }}
                  >
                    <Icon className="w-4 h-4 text-white" strokeWidth={2.5} />
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 pt-0.5">
                    <p className="text-sm font-bold text-[#1A1A1A]">{item.event}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{item.time}</p>
                    {item.status === 'active' && (
                      <motion.div
                        className="mt-1 bg-blue-50 px-2 py-1 rounded-[8px] inline-block"
                        animate={{ opacity: [1, 0.5, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <p className="text-xs text-blue-700 font-bold">In Progress</p>
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.section>

        {/* Share Location Button */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <button
            className="w-full bg-white text-gray-700 rounded-[24px] py-5 px-6 shadow-lg hover:bg-gray-50 active:scale-98 transition-all border-2 border-gray-200"
            onClick={() => {}}
          >
            <div className="flex items-center justify-center gap-2">
              <Share2 className="w-5 h-5" />
              <span className="font-bold text-lg">Share Location</span>
            </div>
          </button>
        </motion.section>

        {/* Back to Dashboard */}
        <button
          onClick={() => navigate("/")}
          className="w-full bg-gray-100 text-gray-700 rounded-[24px] py-4 px-6 shadow-lg hover:bg-gray-200 active:scale-98 transition-all font-bold"
        >
          Back to Dashboard
        </button>
      </div>
    </div>
  );
}