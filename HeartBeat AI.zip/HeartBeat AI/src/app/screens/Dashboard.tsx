import { useState, useEffect } from "react";
import { Activity, Clock, Shield, Languages, Heart } from "lucide-react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { SkeletonOverlay } from "../components/SkeletonOverlay";

export default function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const eventLog = [
    { time: "2:45 PM", event: "Movement detected in living room", type: "normal" },
    { time: "1:30 PM", event: "Heart rate recorded: 72 bpm", type: "normal" },
    { time: "12:15 PM", event: "Medication reminder acknowledged", type: "normal" },
    { time: "10:00 AM", event: "Morning check-in completed", type: "normal" },
    { time: "9:30 AM", event: "System activated", type: "normal" },
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      {/* Header with Logo and Status */}
      <header className="bg-white px-4 py-5 shadow-sm">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#FF4B4B] to-[#FF6B6B] rounded-[12px] flex items-center justify-center shadow-md">
                <Activity className="w-6 h-6 text-white" strokeWidth={2.5} />
              </div>
              <h1 className="text-2xl font-bold text-[#1A1A1A]">HeartBeat AI</h1>
            </div>
            <div className="flex items-center gap-2 bg-[#2ECC71]/10 px-4 py-2 rounded-[24px]">
              <div className="w-2 h-2 bg-[#2ECC71] rounded-full" />
              <span className="text-sm font-semibold text-[#2ECC71]">SECURE</span>
            </div>
          </div>
          
          {/* Privacy Badge */}
          <div className="flex items-center gap-2 bg-blue-50 px-3 py-2 rounded-[16px] border border-blue-100">
            <Shield className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-semibold text-blue-700">Local Processing Only • Privacy First</span>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-6 space-y-4">
        {/* Live Camera Feed */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="bg-white rounded-[24px] overflow-hidden shadow-lg">
            <div className="p-4 pb-3 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-[#1A1A1A]">Edge-AI Live Feed</h2>
                <div className="flex items-center gap-2">
                  <motion.div
                    className="w-2 h-2 bg-[#FF4B4B] rounded-full"
                    animate={{ opacity: [1, 0.3, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="text-xs font-semibold text-gray-600">LIVE</span>
                </div>
              </div>
            </div>
            <div className="relative bg-gray-900 aspect-video">
              <img
                src="https://images.unsplash.com/photo-1667584523543-d1d9cc828a15?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsaXZpbmclMjByb29tJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzcxMzM3NzQwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Living room camera feed"
                className="w-full h-full object-cover opacity-90"
              />
              <SkeletonOverlay width={640} height={360} isFallen={true} />
              
              {/* Fall Detected Status Overlay */}
              <motion.div 
                className="absolute top-3 left-3 bg-[#FF4B4B] px-4 py-2 rounded-[12px] shadow-xl"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <p className="text-white font-bold text-sm">⚠️ STATUS: FALL DETECTED</p>
              </motion.div>
              
              <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-sm px-3 py-1.5 rounded-[12px]">
                <p className="text-white text-xs font-semibold">Living Room • CAM-01</p>
              </div>
              <div className="absolute top-3 right-3 bg-blue-600/90 backdrop-blur-sm px-3 py-1.5 rounded-[12px]">
                <p className="text-white text-xs font-bold">🔒 No Cloud Upload</p>
              </div>
            </div>
            <div className="p-3 bg-gray-50 border-t border-gray-100">
              <p className="text-xs text-gray-600 text-center font-semibold">
                Privacy Secured: All AI processing on local device
              </p>
            </div>
          </div>
        </motion.section>

        {/* Feature List */}
        <motion.div
          className="grid grid-cols-2 gap-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <div className="bg-white rounded-[20px] p-4 shadow-lg">
            <div className="flex items-center gap-2 mb-2">
              <Languages className="w-5 h-5 text-purple-600" />
              <h3 className="font-bold text-sm text-[#1A1A1A]">Multi-Language</h3>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-gray-600 font-semibold">🇬🇧 English</p>
              <p className="text-xs text-gray-600 font-semibold">🇲🇾 Bahasa Melayu</p>
              <p className="text-xs text-gray-600 font-semibold">🇨🇳 中文</p>
            </div>
            <div className="mt-2 bg-green-50 px-2 py-1 rounded-[8px]">
              <p className="text-xs text-green-700 font-bold">NLU Active</p>
            </div>
          </div>

          <div className="bg-white rounded-[20px] p-4 shadow-lg">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="w-5 h-5 text-red-500" />
              <h3 className="font-bold text-sm text-[#1A1A1A]">Vital Tracking</h3>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-gray-600 font-semibold">Heart Rate</p>
              <p className="text-2xl font-bold text-[#FF4B4B]">110 <span className="text-xs text-gray-500">bpm</span></p>
            </div>
            <div className="mt-2 bg-red-50 px-2 py-1 rounded-[8px]">
              <p className="text-xs text-red-700 font-bold">⚠️ Elevated</p>
            </div>
          </div>
        </motion.div>

        {/* Simulate Fall Button */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <Link
            to="/emergency"
            className="block w-full bg-gradient-to-r from-[#FF4B4B] to-[#FF6B6B] text-white rounded-[24px] py-6 px-6 shadow-lg hover:shadow-xl active:scale-98 transition-all"
          >
            <div className="flex items-center justify-center gap-3">
              <span className="text-4xl">⚠️</span>
              <span className="text-2xl font-bold">Simulate Fall</span>
            </div>
          </Link>
        </motion.section>

        {/* Event Log */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <div className="bg-white rounded-[24px] overflow-hidden shadow-lg">
            <div className="p-4 pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#1A1A1A]" />
                <h2 className="font-bold text-[#1A1A1A]">Activity Log</h2>
              </div>
            </div>
            <div className="p-4 space-y-3">
              {eventLog.map((log, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-3 p-3 bg-gray-50 rounded-[16px]"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.05 }}
                >
                  <div className="w-8 h-8 bg-[#2ECC71]/10 rounded-[10px] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="w-2 h-2 bg-[#2ECC71] rounded-full" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#1A1A1A]">{log.event}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{log.time} • Today</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>
      </div>
    </div>
  );
}