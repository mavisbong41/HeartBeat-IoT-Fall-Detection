import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { AlertTriangle } from "lucide-react";
import { PulseWaveIcon } from "../components/PulseWaveIcon";
import { useNavigate } from "react-router";

export default function EmergencyAlert() {
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(60);
  const [holdProgress, setHoldProgress] = useState(0);
  const [isHolding, setIsHolding] = useState(false);
  const [holdStartTime, setHoldStartTime] = useState<number | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          navigate("/caregiver-tracking");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [navigate]);

  useEffect(() => {
    let animationFrame: number;
    
    const updateProgress = () => {
      if (isHolding && holdStartTime) {
        const elapsed = Date.now() - holdStartTime;
        const progress = Math.min((elapsed / 3000) * 100, 100);
        setHoldProgress(progress);
        
        if (progress >= 100) {
          // Cancel alert and go back
          navigate("/");
          return;
        }
        
        animationFrame = requestAnimationFrame(updateProgress);
      }
    };
    
    if (isHolding) {
      animationFrame = requestAnimationFrame(updateProgress);
    }
    
    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [isHolding, holdStartTime, navigate]);

  const handleOk = () => {
    navigate("/");
  };

  const handleHelp = () => {
    navigate("/caregiver-tracking");
  };

  const handleCancelStart = () => {
    setIsHolding(true);
    setHoldStartTime(Date.now());
  };

  const handleCancelEnd = () => {
    setIsHolding(false);
    setHoldStartTime(null);
    setHoldProgress(0);
  };

  return (
    <div className="min-h-screen bg-[#F39C12] flex flex-col">
      {/* Alert Icon */}
      <motion.div
        className="flex-1 flex flex-col items-center justify-center px-4 py-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <motion.div
          className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-2xl mb-8"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.6 }}
        >
          <motion.div
            animate={{ rotate: [0, -10, 10, -10, 0] }}
            transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
          >
            <AlertTriangle className="w-20 h-20 text-[#F39C12]" strokeWidth={2.5} />
          </motion.div>
        </motion.div>

        {/* Pulse Wave Visualization */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <PulseWaveIcon />
        </motion.div>

        {/* Alert Text */}
        <motion.div
          className="text-center mb-8 px-6 max-w-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h1 className="text-4xl font-bold text-white mb-3">
            CRITICAL: Potential Fall Detected!
          </h1>
          <p className="text-xl text-white font-semibold mb-4">
            System is listening... Are you okay?
          </p>
          <div className="bg-white/20 backdrop-blur-sm rounded-[20px] p-4">
            <p className="text-sm text-white/90 mb-1">
              Please say OK or HELP / Sila cakap OK / 请说 OK
            </p>
          </div>
        </motion.div>

        {/* Countdown Timer Bar */}
        <motion.div
          className="w-full max-w-md px-4 mb-8"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="bg-white/20 backdrop-blur-sm rounded-[24px] p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-3xl">🚑</span>
                <span className="text-white font-bold">Ambulance auto-call in:</span>
              </div>
              <motion.span
                className="text-white font-bold text-3xl"
                key={countdown}
                initial={{ scale: 1.3 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                {countdown}s
              </motion.span>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full bg-white/30 rounded-full h-3 overflow-hidden">
              <motion.div
                className="h-full bg-white rounded-full"
                initial={{ width: "100%" }}
                animate={{ width: `${(countdown / 60) * 100}%` }}
                transition={{ duration: 1, ease: "linear" }}
              />
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <div className="w-full max-w-md px-4 space-y-4">
          <motion.button
            onClick={handleOk}
            className="w-full bg-[#2ECC71] text-white rounded-[24px] py-7 px-8 shadow-2xl font-bold text-2xl flex items-center justify-center gap-3 hover:bg-[#27AE60] active:scale-98 transition-all"
            initial={{ opacity: 0, x: -100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            whileTap={{ scale: 0.98 }}
          >
            <span className="text-3xl">✅</span>
            <span>I'M OK</span>
          </motion.button>

          <motion.button
            onClick={handleHelp}
            className="w-full bg-[#FF4B4B] text-white rounded-[24px] py-7 px-8 shadow-2xl font-bold text-2xl flex items-center justify-center gap-3 hover:bg-[#E63939] active:scale-98 transition-all"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7 }}
            whileTap={{ scale: 0.98 }}
          >
            <span className="text-3xl">🚑</span>
            <span>REQUEST HELP</span>
          </motion.button>
        </div>

        {/* Cancel Alert Button with Press & Hold */}
        <motion.div
          className="w-full max-w-md px-4 mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <div className="relative">
            <button
              onMouseDown={handleCancelStart}
              onMouseUp={handleCancelEnd}
              onMouseLeave={handleCancelEnd}
              onTouchStart={handleCancelStart}
              onTouchEnd={handleCancelEnd}
              className="w-full bg-[#FF4B4B] text-white rounded-[24px] py-6 px-8 font-bold text-xl border-2 border-white/50 active:scale-98 transition-all relative overflow-hidden shadow-2xl"
            >
              {/* Progress Fill */}
              <motion.div
                className="absolute inset-0 bg-[#8B0000] rounded-[24px]"
                style={{ width: `${holdProgress}%`, left: 0 }}
                transition={{ duration: 0.05 }}
              />
              
              <div className="relative z-10">
                {isHolding ? (
                  <>
                    <div className="text-2xl mb-1">RELEASING...</div>
                    <div className="text-sm opacity-90">
                      Hold for {Math.ceil((3 - (holdProgress / 100) * 3))} more seconds
                    </div>
                  </>
                ) : (
                  <>
                    <div className="text-2xl mb-1">PRESS & HOLD 3 SECONDS</div>
                    <div className="text-sm opacity-90">TO CANCEL</div>
                  </>
                )}
              </div>
            </button>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}